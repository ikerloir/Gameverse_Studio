using System.Collections;
using TMPro;
using UnityEngine;

public class IntroUIManager : MonoBehaviour
{
    [Header("Texto de introducci�n")]
    public TextMeshProUGUI introText;

    [Header("Duraci�n en segundos")]
    public float displayDuration = 3f;

    [Header("Objetos que se activan despu�s de la intro")]
    public GameObject[] objectsToActivate;

    void Start()
    {
        // Asegura que el texto est� activo al iniciar
        if (introText != null)
        {
            introText.gameObject.SetActive(true);
            StartCoroutine(ShowIntro());
        }
        else
        {
            Debug.LogWarning("No se ha asignado un TextMeshProUGUI al IntroUIManager.");
        }
    }

    IEnumerator ShowIntro()
    {
        yield return new WaitForSeconds(displayDuration);

        // Oculta el texto y activa otros objetos
        introText.gameObject.SetActive(false);

        foreach (GameObject obj in objectsToActivate)
        {
            if (obj != null)
                obj.SetActive(true);
        }
    }
}
