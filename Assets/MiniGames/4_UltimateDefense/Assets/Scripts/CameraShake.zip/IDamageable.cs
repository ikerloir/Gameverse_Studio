using UnityEngine; // <- Esto es lo que falta

public interface IDamageable
{
    void TakeDamage(float amount, GameObject source);
}
