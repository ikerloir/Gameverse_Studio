﻿
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class HUDManager : MonoBehaviour
{
    [Header("Referencias de Texto")]
    public TextMeshProUGUI healthText;
    public TextMeshProUGUI damageReceivedText;
    public TextMeshProUGUI killsText;

    [Header("Panel de Resultado")]
    public GameObject panelResultados;
    public TextMeshProUGUI resultadoText;
    public TextMeshProUGUI puntuacionFinalText;

    [Header("Música")]
    public AudioSource audioSource;
    public AudioClip victoriaClip;
    public AudioClip derrotaClip;
    public float duracionMusica = 5f;

    private int currentKills = 0;
    private int currentHealth = 100;

    [Header("Configuración de juego")]
    public int maxHealth = 100;
    public int killsParaGanar = 5;

    private bool juegoTerminado = false;

    private Vector3 originalDamageTextPosition;
    private Color originalDamageTextColor;
    private float fadeDuration = 1.5f;
    private float fadeTimer;

    void Start()
    {
        currentHealth = maxHealth;
        UpdateHealth(currentHealth);

        if (damageReceivedText != null)
        {
            originalDamageTextPosition = damageReceivedText.rectTransform.localPosition;
            originalDamageTextColor = damageReceivedText.color;
            damageReceivedText.gameObject.SetActive(false);
        }

        if (panelResultados != null)
        {
            panelResultados.SetActive(false);
        }
    }

    public void UpdateHealth(int value)
    {
        if (juegoTerminado) return;

        currentHealth = value;
        if (healthText != null)
            healthText.text = currentHealth.ToString();

        if (currentHealth <= 0)
        {
            Derrota();
        }
    }

    public void ShowDamageReceived(float damage)
    {
        if (juegoTerminado) return;

        currentHealth -= Mathf.RoundToInt(damage);
        UpdateHealth(currentHealth);

        if (damageReceivedText != null)
        {
            damageReceivedText.text = "-" + damage.ToString("F0");
            damageReceivedText.rectTransform.localPosition = originalDamageTextPosition;
            damageReceivedText.color = originalDamageTextColor;
            damageReceivedText.gameObject.SetActive(true);
            fadeTimer = fadeDuration;

            CancelInvoke(nameof(HideDamageText));
            CancelInvoke(nameof(AnimateDamageText));
            InvokeRepeating(nameof(AnimateDamageText), 0f, 0.016f);
            Invoke(nameof(HideDamageText), fadeDuration);
        }
    }

    private void AnimateDamageText()
    {
        if (damageReceivedText != null)
        {
            damageReceivedText.rectTransform.localPosition += new Vector3(0, 0.5f, 0);
            fadeTimer -= 0.016f;
            float alpha = Mathf.Clamp01(fadeTimer / fadeDuration);
            Color color = damageReceivedText.color;
            color.a = alpha;
            damageReceivedText.color = color;
        }
    }

    private void HideDamageText()
    {
        if (damageReceivedText != null)
        {
            CancelInvoke(nameof(AnimateDamageText));
            damageReceivedText.gameObject.SetActive(false);
            damageReceivedText.rectTransform.localPosition = originalDamageTextPosition;
            damageReceivedText.color = originalDamageTextColor;
        }
    }

    public void AddKill()
    {
        if (juegoTerminado) return;

        currentKills++;
        if (killsText != null)
            killsText.text = currentKills.ToString();

        if (currentKills >= killsParaGanar)
        {
            Victoria();
        }
    }

    private void Victoria()
    {
        juegoTerminado = true;
        ReproducirMusica(victoriaClip);
        MostrarResultado("✅ ¡Victoria! Has defendido el aeropuerto.");
    }

    private void Derrota()
    {
        juegoTerminado = true;
        ReproducirMusica(derrotaClip);
        MostrarResultado("❌ Derrota. El aeropuerto está indefenso.");
    }

    private void MostrarResultado(string mensaje)
    {
        if (panelResultados != null)
        {
            panelResultados.SetActive(true);
        }

        if (resultadoText != null)
        {
            resultadoText.text = mensaje;
        }

        Invoke(nameof(MostrarPuntuacionFinal), 2f);
    }

    private void MostrarPuntuacionFinal()
    {
        if (puntuacionFinalText != null)
        {
            puntuacionFinalText.text = "🏆 Puntuación total: " + currentKills;
        }
    }

    private void ReproducirMusica(AudioClip clip)
    {
        if (audioSource != null && clip != null)
        {
            audioSource.clip = clip;
            audioSource.loop = false;
            audioSource.Play();
            Invoke(nameof(DetenerMusica), duracionMusica);
        }
    }

    private void DetenerMusica()
    {
        if (audioSource != null)
        {
            audioSource.Stop();
        }
    }

    public void Reintentar()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
